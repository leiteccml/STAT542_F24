############################################################################################
# STAT 542 - Statistical Learning                                                          #
# Project 04: Movie Recommender System                                                     #
# Code: myIBCF.R                                                                           #
# Author: Carolina Carvalho Manhaes Leite, leite2, 651660086                               #
# Date: Dec 16, 2024                                                                       #
############################################################################################

myIBCF <- function(newuser) {
  # Copying input to a vector w #
  w <- newuser
  # Importing matrix R #
  #R <- read.csv(url('https://github.com/leiteccml/STAT542_F24/raw/main/Rmat.csv'))
  # Importing RDS object with the column names of the matrix R #
  R_colnames <- readRDS(url('https://github.com/leiteccml/STAT542_F24/raw/main/R_colnames.rds'))
  # Importing the final df from System I #
  systemI <- readRDS(url('https://github.com/leiteccml/STAT542_F24/raw/main/systemI.rds'))
  # Transforming column `MovieID` so that it takes the format `m...` #
  systemI$MovieID <- paste0("m",systemI$MovieID)
  # Defining function "not in" #
  '%!in%' <- function(x,y)!('%in%'(x,y))
  # Checking if `w` is a vector of dimension 3706-by-1 #
  #if ((is.vector(w) == FALSE) | (length(w) != NCOL(R))) {
  if ((is.vector(w) == FALSE) | (length(w) != length(R_colnames))) {
    stop("Error: w is not a vector of dimension 3706-by-1.")
  }
  # Checking if the non-NA values of `w` lie outside the domain c(1,2,3,4,5) #
  if (any(w[!is.na(w)] %!in% c(1,2,3,4,5))) {
    stop("Error: w contains ratings that are not in the domain {1,2,3,4,5}.")    
  }
  # Checking if `w` is all NA's. If it is, moves on to the backup plan (System I) right away #
  if (all(is.na(w)) == TRUE) {
    # Selecting top 10 movies based on System I #
    systemII <- systemI[1:10,]
    # Transforming the data frame above into a vector with the average ratings as elements and the `MovieID` column as the names #
    pred_02 <- systemII$avg_ratings
    names(pred_02) <- systemII$MovieID 
  } else {
    # Loading the similarity matrix obtained as output of Step 3 #
    S <- matrix(readRDS(url('https://github.com/leiteccml/STAT542_F24/raw/main/S_top30_v2.rds')), nrow = length(R_colnames), ncol = length(R_colnames))
    # Renaming rows and columns #
    rownames(S) <- R_colnames
    colnames(S) <- R_colnames
    # Making sure the output has 7 decimal points #
    S <- round(S, digits = 7) 
    # Filtering matrix S so that the resulting matrix only has the rows that correspond to the movies not rated yet, and the columns of the movies that have been rated by the user #
    S_filtered <- S[which(is.na(w)),which(!is.na(w)), drop = FALSE]
    # Multiplying each row by the vector of weights #
    S_weighted <- sweep(S_filtered, 2, w[!is.na(w)], FUN = "*")
    # Computing the prediction for each row in the filtered S matrix #
    pred_01 <- rowSums(S_weighted, na.rm = TRUE)/rowSums(S_filtered, na.rm = TRUE)
    # Attaching movie names to the predictions #
    names(pred_01) <- rownames(S_filtered)
    # Sorting predictions in descending order #
    pred_01 <- sort(pred_01, decreasing = TRUE)
    # If fewer than 10 predictions are non-NA, we select the remaining movies based on the popularity defined in System I #
    if (sum(!is.na(pred_01)) < 10) {
      # Getting the names of the movies already ranked by the user #
      movies_already_ranked <- colnames(S_filtered)
      # Removing from the System I data set the movies above #
      systemI_bckup <- systemI[systemI$MovieID %!in% movies_already_ranked,]
      systemI_bckup <- systemI_bckup[1:(10-sum(!is.na(pred_01))),]
      # Transforming the data frame above into a vector with the average ratings as elements and the `MovieID` column as the names #
      systemI_bckup_vec <- systemI_bckup$avg_ratings
      names(systemI_bckup_vec) <- systemI_bckup$MovieID
      # Stacking the two vectors (i.e., the one with the predictions and the backup from System I) #
      pred_02 <- c(pred_01,systemI_bckup_vec)
    } else {
      pred_02 <- pred_01
    }
  }
  # Transforming vector of predictions into a data frame #
  df_pred <- data.frame(cbind(MovieID = names(pred_02), Prediction = pred_02))
  df_pred$Prediction <- as.numeric(df_pred$Prediction)
  rownames(df_pred) <- NULL
  # Sorting data frame by descending value of Prediction and ascending value of `MovieID` #
  df_pred_01 <- df_pred[order(-df_pred$Prediction, df_pred$MovieID),]
  # Transforming data frame back to vector #
  pred_03 <- df_pred_01$Prediction
  names(pred_03) <- df_pred_01$MovieID
  # Returning top-10 recommendations #
  return(pred_03[1:10])
}