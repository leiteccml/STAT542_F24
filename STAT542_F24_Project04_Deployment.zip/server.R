############################################################################################
# STAT 542 - Statistical Learning                                                          #
# Project 04: Movie Recommender System                                                     #
# Code: server.R                                                                           #
# Author: Carolina Carvalho Manhaes Leite, leite2, 651660086                               #
# Date: Dec 16, 2024                                                                       #
############################################################################################

# Loading function with the IBCF recommender #
source('myIBCF.R') 

get_user_ratings = function(value_list) {
  dat = data.table(MovieID = sapply(strsplit(names(value_list), "_"), 
                                    function(x) ifelse(length(x) > 1, x[[2]], NA)),
                   Rating = unlist(as.character(value_list)))
  dat = dat[!is.null(Rating) & !is.na(MovieID)]
  dat[Rating == " ", Rating := 0]
  dat[, ':=' (MovieID = as.numeric(MovieID), Rating = as.numeric(Rating))]
  dat = dat[Rating > 0]
}

# Importing and manipulating data from the movies.dat data set #
myurl = "https://liangfgithub.github.io/MovieData/"
movies = readLines(paste0(myurl, 'movies.dat?raw=true'))
movies = strsplit(movies, split = "::", fixed = TRUE, useBytes = TRUE)
movies = matrix(unlist(movies), ncol = 3, byrow = TRUE)
movies = data.frame(movies, stringsAsFactors = FALSE)
colnames(movies) = c('MovieID', 'Title', 'Genres')
movies$MovieID = as.integer(movies$MovieID)
movies$Title = iconv(movies$Title, "latin1", "UTF-8")
small_image_url = "https://liangfgithub.github.io/MovieImages/"
movies$image_url = sapply(movies$MovieID, 
                          function(pic) paste0(small_image_url, pic, '.jpg?raw=true'))

# Importing matrix R #
R <- read.csv(url('https://github.com/leiteccml/STAT542_F24/raw/main/Rmat.csv'))
# Extracting names of movies from matrix R #
df_movies_IDs_01 <- data.frame(MovieID = as.numeric(sub('.', '', colnames(R))))

shinyServer(function(input, output, session) {
  
  # show the books to be rated
  output$ratings <- renderUI({
    num_rows <- 20
    num_movies <- 6 # movies per row
    
    lapply(1:num_rows, function(i) {
      list(fluidRow(lapply(1:num_movies, function(j) {
        list(box(width = 2,
                 div(style = "text-align:center", img(src = movies$image_url[(i - 1) * num_movies + j], height = 150)),
                 #div(style = "text-align:center; color: #999999; font-size: 80%", books$authors[(i - 1) * num_books + j]),
                 div(style = "text-align:center", strong(movies$Title[(i - 1) * num_movies + j])),
                 div(style = "text-align:center; font-size: 150%; color: #f0ad4e;", ratingInput(paste0("select_", movies$MovieID[(i - 1) * num_movies + j]), label = "", dataStop = 5)))) #00c0ef
      })))
    })
  })
  
  # Calculate recommendations when the sbumbutton is clicked
  df <- eventReactive(input$btn, {
    withBusyIndicatorServer("btn", { # showing the busy indicator
      # hide the rating container
      useShinyjs()
      jsCode <- "document.querySelector('[data-widget=collapse]').click();"
      runjs(jsCode)
      
      # get the user's rating data
      value_list <- reactiveValuesToList(input)
      user_ratings <- get_user_ratings(value_list)
      # Left join between the `movies_IDs` data frame and the user input, so we keep the order from the R matrix #
      df_movies_IDs_02 <- left_join(df_movies_IDs_01, user_ratings, by = "MovieID")
      # Extracting the `MovieID` column as a vector #
      w <- df_movies_IDs_02$Rating
      # Attaching movie names back to the vector above #
      names(w) <- colnames(R)
      # Calling `myIBCF` function #
      rec <- myIBCF(w) 
      # Transforming result to a data frame #
      df_rec <- data.frame(MovieID = as.numeric(sub('.', '', names(rec))), Predicted_rating = unname(rec))
      # Inner join between the table `movie` and the data frame above #
      movies_02 <- left_join(df_rec, movies, by = "MovieID")
      recom_results <- data.table(Rank = 1:10, 
                                  MovieID = movies_02$MovieID, 
                                  Title = movies_02$Title, 
                                  Predicted_rating =  movies_02$Predicted_rating,
                                  image_url = movies_02$image_url)
    }) # still busy
    
  }) # clicked on button
  
  
  # display the recommendations
  output$results <- renderUI({
    num_rows <- 2
    num_movies <- 5
    recom_result <- df()
    
    lapply(1:num_rows, function(i) {
      list(fluidRow(lapply(1:num_movies, function(j) {
        box(width = 2, status = "success", solidHeader = TRUE, title = paste0("Rank ", (i - 1) * num_movies + j),
            
            div(style = "text-align:center", 
                a(img(src = recom_result$image_url[(i - 1) * num_movies + j], height = 150))
                #a(img(src = movies$image_url[recom_result$MovieID[(i - 1) * num_movies + j]], height = 150))
            ),
            div(style="text-align:center; font-size: 100%", 
                strong(recom_result$Title[(i - 1) * num_movies + j])
                #strong(movies$Title[recom_result$MovieID[(i - 1) * num_movies + j]])
            )
            
        )        
      }))) # columns
    }) # rows
    
  }) # renderUI function
  
}) # server function
